# Raydium Frontend

# url(query) support

## Swap

- ammid
- inputCurrency (v1:from)
- outputCurrency (v1:to)
- inputAmount
- outputAmount

## Liquidity

- ammid
- coin0
- coin1
- amount0
- amount1

## Farm

- farmid
